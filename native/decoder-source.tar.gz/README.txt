Rust decoder source for qr_scanner_offline_private

This archive contains the decoder source, Cargo.lock, Rust toolchain
specification, vendored crate sources and their original licenses, and an
independent rebuild script. The parent Flutter package provides the Dart bindings, binary-selection hook
and additional third-party notices. LICENSE applies to the decoder code; each
vendored dependency retains its own licenses.

Rebuilding the six Android and iOS dynamic libraries
---------------------------------------------------
1. On macOS, install Xcode with the iOS device and simulator SDKs and command
   line tools. Install Rust 1.90.0 and the six targets in rust-toolchain.toml,
   for example with rustup. Install Android NDK 28.2.13676358.
2. Extract this archive to a writable directory. In a terminal in that directory:

     export ANDROID_NDK_HOME=/path/to/android/ndk/28.2.13676358
     ./rebuild.sh

   Ensure cargo and rustc 1.90.0 are on PATH. The script uses the vendored
   sources, --locked and --offline, and builds all targets without the Flutter
   example app or native_toolchain_rust. It writes its output under out/ and
   intermediate Cargo artifacts under target/.
3. Inspect the output, test it on the target platforms and update the package's
   native files and SHA256SUMS before distribution. Android outputs use API 24
   and 16 KiB maximum page alignment; iOS output install names are normalized
   with install_name_tool. The iOS device and x64 simulator deployment targets
   are 10.0; the arm64 simulator target is 14.0. Host dependencies may require
   higher deployment targets.

To rebuild one target independently, use cargo build --release --locked
--offline --target <target-triple> from the extracted directory with its
appropriate linker, SDK and flags; rebuild.sh records these settings.
Toolchain and SDK version, flags, path remapping, and platform can change the
output. A matching source and successful rebuild do not by themselves ensure
bit-for-bit reproducibility or device behavior. Preserve all included license
notices when redistributing these sources or derived binaries.
