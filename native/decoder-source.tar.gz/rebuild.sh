#!/usr/bin/env bash
set -euo pipefail

# Rebuild the six packaged libraries from the vendored source archive.
# Requires Rust 1.90.0 and its six targets, Android NDK, Xcode and iOS SDKs.
cd "$(dirname "$0")"
source_dir=$(pwd -P)
: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to the Android NDK directory}"
case "$(uname -s)" in
  Darwin) ndk_host=darwin-x86_64 ;;
  *) printf '%s\n' 'Building all targets requires macOS with Xcode.' >&2; exit 1 ;;
esac
ndk_bin="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/$ndk_host/bin"
if [[ ! -x "$ndk_bin/aarch64-linux-android24-clang" ]]; then
  printf '%s\n' 'Android NDK API 24 compiler not found.' >&2; exit 1
fi
if [[ "$(rustc --version)" != 'rustc 1.90.0 '* ]]; then
  printf '%s\n' 'Rust 1.90.0 is required; check the active toolchain.' >&2; exit 1
fi
xcrun --sdk iphoneos --show-sdk-path >/dev/null
xcrun --sdk iphonesimulator --show-sdk-path >/dev/null
export CARGO_TARGET_DIR="$source_dir/target"
# Encoded flags preserve paths containing spaces. Remapping reduces local paths
# in generated artifacts; inspect every output before publishing it.
sep=$(printf '\037')
base_flags="--remap-path-prefix=$source_dir=/build/source"
if [[ -n "${HOME:-}" ]]; then base_flags="$base_flags${sep}--remap-path-prefix=$HOME=/build/user"; fi
build_android() {
  local target=$1 linker_var=$2 compiler=$3 output=$4
  export CARGO_ENCODED_RUSTFLAGS="${base_flags}${sep}-C${sep}link-arg=-Wl,-z,max-page-size=16384"
  env "$linker_var=$ndk_bin/$compiler" cargo build --release --locked --offline --target "$target"
  mkdir -p "out/android/$output"
  cp "target/$target/release/libqr_decoder.so" "out/android/$output/libqr_decoder.so"
}
build_ios() {
  local target=$1 sdk=$2 minimum=$3 output=$4
  export CARGO_ENCODED_RUSTFLAGS="$base_flags"
  export SDKROOT
  SDKROOT=$(xcrun --sdk "$sdk" --show-sdk-path)
  IPHONEOS_DEPLOYMENT_TARGET="$minimum" cargo build --release --locked --offline --target "$target"
  mkdir -p "out/ios/$output"
  cp "target/$target/release/libqr_decoder.dylib" "out/ios/$output/libqr_decoder.dylib"
  install_name_tool -id @rpath/libqr_decoder.dylib "out/ios/$output/libqr_decoder.dylib"
}
build_android armv7-linux-androideabi CARGO_TARGET_ARMV7_LINUX_ANDROIDEABI_LINKER armv7a-linux-androideabi24-clang arm
build_android aarch64-linux-android CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER aarch64-linux-android24-clang arm64
build_android x86_64-linux-android CARGO_TARGET_X86_64_LINUX_ANDROID_LINKER x86_64-linux-android24-clang x64
build_ios aarch64-apple-ios iphoneos 10.0 device/arm64
build_ios aarch64-apple-ios-sim iphonesimulator 14.0 simulator/arm64
build_ios x86_64-apple-ios iphonesimulator 10.0 simulator/x64
printf '%s\n' 'Built decoders in out/. Inspect and test before distribution.'
